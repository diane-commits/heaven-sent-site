# Heaven Sent — Next.js Website (Ready for Vercel)

This is a production‑ready Next.js 14 + Tailwind site for Heaven Sent House Cleaning.

## Quick Start (Local)
1. Install deps: `npm install`
2. Run dev: `npm run dev`
3. Build: `npm run build`
4. Start: `npm start`

## Deploy to Vercel
1. Create a Vercel account at https://vercel.com (use Google login).
2. Click **New Project** → **Import** → select your GitHub repo (or use **Deploy from Git** and push this folder).
   - Alternatively, use **Vercel CLI**: `npm i -g vercel` then run `vercel` in this folder.
3. After first deploy, go to **Settings → Domains** and add `heavensentprosolutions.com`.
4. Update DNS at your registrar to the A/ALIAS/CNAME records Vercel gives you.
5. Wait for DNS to propagate, then your site is live on HTTPS.

## Customization
- Update `app/page.tsx` for content.
- Replace `/public/favicon.ico` with your logo.
- When you have a Jobber link, replace `bookingUrl` in `app/page.tsx`.
