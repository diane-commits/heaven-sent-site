# Heaven Sent — Next.js Website (Vercel Ready)

This is a production‑ready Next.js 14 + Tailwind site for **Heaven Sent House Cleaning**.

## Deploy to Vercel (GitHub flow)
1) Upload these files to a new GitHub repo (root level).
2) In Vercel: New Project → Import from GitHub → select the repo → Deploy.
3) In Project → Settings → Domains → add `heavensentprosolutions.com` and follow DNS steps.

## Customize
- Edit content in `app/page.tsx` (phone, hours, pricing, etc.).
- Replace `/public/favicon.ico` with your logo if you have one.
- Update `bookingUrl` with your Jobber booking link when ready.
