"use client";
import { motion } from "framer-motion";
import { Phone, Mail, CalendarCheck2, Star, Clock, MapPin, Sparkles, ShieldCheck, BadgeCheck, CreditCard, CheckCircle, Info } from "lucide-react";

const features = [
  { icon: <Sparkles className="w-6 h-6" aria-hidden />, title: "Meticulous Standard", text: "Every visit follows a detailed checklist so nothing gets missed." },
  { icon: <ShieldCheck className="w-6 h-6" aria-hidden />, title: "Vetted & Insured", text: "Professionally trained pros. Your home and time are respected." },
  { icon: <BadgeCheck className="w-6 h-6" aria-hidden />, title: "Satisfaction Promise", text: "If anything's not right, we make it right—fast." },
];

const services = [
  { name: "Standard Home Cleaning", blurb: "Kitchens, baths, living areas, and bedrooms—kept consistently fresh.", bullets: ["Dust & surfaces", "Floors vacuumed/mopped", "Kitchen wipe-down", "Bathrooms refreshed"] },
  { name: "Deep Cleaning", blurb: "A top-to-bottom reset—perfect seasonally or before guests.", bullets: ["Baseboards & doors", "Cabinet fronts", "Detail in kitchen & baths", "Built-up grime removal"] },
  { name: "Move‑In/Move‑Out", blurb: "Empty home shine—helps deposits and listing photos.", bullets: ["Inside cabinets & drawers", "Appliances in/out", "Tracks & edges", "Final walkthrough"] },
];

const prices = [
  { tier: "3‑Room Special", price: "$150", note: "Any 3 rooms • Standard clean", cta: "Book Special" },
  { tier: "Studio/1‑Bed From", price: "$139", note: "Standard clean", cta: "Book Now" },
  { tier: "Deep Clean From", price: "$299", note: "Top‑to‑bottom reset", cta: "Get Quote" },
];

export default function Page() {
  const business = {
    name: "Heaven Sent House Cleaning",
    phone: "480-925-1762",
    email: "diane@heavensenthousecleaning.com",
    tagline: "Heaven Sent – Sparkle Without Lifting a Finger.",
    serviceArea: "Mesa & Greater Phoenix, AZ",
    hours: "Mon–Fri, 8:00 AM – 4:00 PM",
    bookingUrl: "#book",
    addressShort: "Mesa, AZ",
  };

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 selection:bg-yellow-200/70">
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-neutral-200">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 shadow-inner grid place-items-center" aria-hidden>
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-semibold leading-tight">{business.name}</p>
              <p className="text-xs text-neutral-500 -mt-0.5">{business.tagline}</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#services" className="hover:opacity-70">Services</a>
            <a href="#pricing" className="hover:opacity-70">Pricing</a>
            <a href="#reviews" className="hover:opacity-70">Reviews</a>
            <a href="#contact" className="hover:opacity-70">Contact</a>
            <a href={business.bookingUrl} className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-amber-500 text-white shadow hover:shadow-md">
              <CalendarCheck2 className="w-4 h-4" /> Book
            </a>
          </nav>
          <a href={`tel:${business.phone}`} className="md:hidden inline-flex items-center gap-2 px-3 py-2 rounded-2xl bg-neutral-900 text-white">
            <Phone className="w-4 h-4" /> Call
          </a>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-100 via-white to-yellow-50 pointer-events-none" aria-hidden />
        <div className="max-w-6xl mx-auto px-4 py-20">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight leading-tight">
                A spotless home—<span className="text-amber-600"> without lifting a finger.</span>
              </h1>
              <p className="mt-4 text-neutral-700 text-lg max-w-[55ch]">
                Trusted, professional cleaners serving {business.serviceArea}. Fixed upfront pricing* and friendly, on‑time service.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <a href={business.bookingUrl} className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-amber-500 text-white text-sm font-semibold shadow hover:shadow-md">
                  <CalendarCheck2 className="w-5 h-5" /> Book a Cleaning
                </a>
                <a href={`tel:${business.phone}`} className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-white border border-neutral-300 text-neutral-900 text-sm font-semibold hover:bg-neutral-50">
                  <Phone className="w-5 h-5" /> {business.phone}
                </a>
              </div>
              <p className="mt-3 text-xs text-neutral-500 flex items-center gap-1"><Info className="w-4 h-4" /> *Actual home or office size can increase price.</p>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="relative">
              <div className="aspect-[4/3] rounded-3xl bg-white shadow-lg overflow-hidden">
                <div className="absolute inset-0 grid grid-cols-2 gap-1 p-1">
                  <div className="bg-[url('https://images.unsplash.com/photo-1604881987923-620a7b6283f2?q=80&w=1974&auto=format&fit=crop')] bg-cover bg-center rounded-2xl" role="img" aria-label="Clean kitchen shining" />
                  <div className="bg-[url('https://images.unsplash.com/photo-1604881987661-3ac1fdc7459b?q=80&w=1974&auto=format&fit=crop')] bg-cover bg-center rounded-2xl" role="img" aria-label="Fresh living room" />
                </div>
              </div>
            </motion.div>
          </div>

          <div className="mt-10 grid sm:grid-cols-3 gap-4">
            {features.map((f) => (
              <div key={f.title} className="rounded-2xl bg-white p-5 shadow border border-neutral-200">
                <div className="flex items-start gap-3">
                  <div className="text-amber-600" aria-hidden>{f.icon}</div>
                  <div>
                    <h3 className="font-semibold">{f.title}</h3>
                    <p className="text-sm text-neutral-600">{f.text}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="services" className="py-16 bg-white border-t border-neutral-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold tracking-tight">Services</h2>
          <p className="text-neutral-600 mt-2">Residential • Commercial • Move‑In/Out • Airbnb Turnovers</p>
          <div className="mt-8 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {services.map((s) => (
              <div key={s.name} className="rounded-2xl p-5 border border-neutral-200 bg-neutral-50 hover:bg-white hover:shadow transition">
                <h3 className="font-semibold text-lg">{s.name}</h3>
                <p className="text-sm text-neutral-600 mt-1">{s.blurb}</p>
                <ul className="mt-3 space-y-1 text-sm text-neutral-700">
                  {s.bullets.map((b) => (
                    <li key={b} className="flex items-center gap-2"><CheckCircle className="w-4 h-4" aria-hidden /> {b}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="pricing" className="py-16 bg-neutral-50 border-y border-neutral-200">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold tracking-tight">Simple Pricing</h2>
          <p className="text-neutral-600 mt-2">Upfront rates with no surprises*</p>
          <div className="mt-8 grid md:grid-cols-3 gap-5">
            {prices.map((p) => (
              <div key={p.tier} className="rounded-2xl p-6 bg-white border border-neutral-200 shadow-sm">
                <h3 className="font-semibold text-lg">{p.tier}</h3>
                <p className="text-4xl font-extrabold mt-2">{p.price}</p>
                <p className="text-sm text-neutral-600 mt-1">{p.note}</p>
                <a href={business.bookingUrl} className="mt-5 inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-amber-500 text-white text-sm font-semibold shadow hover:shadow-md">
                  <CalendarCheck2 className="w-4 h-4" /> {p.cta}
                </a>
                <p className="mt-3 text-xs text-neutral-500">*Actual home or office size can increase price.</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="reviews" className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold tracking-tight">Recent Reviews</h2>
          <p className="text-neutral-600 mt-2">A few words from happy clients</p>
          <div className="mt-8 grid md:grid-cols-3 gap-5">
            {[
              { name: "Susan H.", text: "Incredible job—sparkling results and very professional.", stars: 5 },
              { name: "Michael R.", text: "On time, detail‑oriented, and friendly. Highly recommend!", stars: 5 },
              { name: "Alyssa K.", text: "They went above and beyond on our move‑out clean.", stars: 5 },
            ].map((r, i) => (
              <div key={i} className="rounded-2xl p-6 border border-neutral-200 bg-neutral-50">
                <div className="flex items-center gap-2 text-amber-500" aria-label={`${r.stars} out of 5 stars`}>
                  {Array.from({ length: r.stars }).map((_, idx) => <Star key={idx} className="w-4 h-4 fill-current" />)}
                </div>
                <p className="mt-3 text-neutral-800">“{r.text}”</p>
                <p className="mt-2 text-sm text-neutral-500">— {r.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="book" className="py-14 bg-gradient-to-br from-yellow-100 via-white to-amber-50 border-y border-neutral-200">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Ready for a little Heaven Sent help?</h2>
            <p className="mt-2 text-neutral-700">Book a time that works for you. We'll confirm availability by text or email.</p>
            <ul className="mt-4 text-sm text-neutral-700 space-y-1">
              <li className="flex items-center gap-2"><Clock className="w-4 h-4" /> {business.hours}</li>
              <li className="flex items-center gap-2"><MapPin className="w-4 h-4" /> {business.serviceArea}</li>
              <li className="flex items-center gap-2"><CreditCard className="w-4 h-4" /> Zelle, Venmo, Cash, Check</li>
            </ul>
          </div>
          <div className="rounded-3xl bg-white border border-neutral-200 p-6 shadow-sm">
            <form className="grid gap-3">
              <div>
                <label className="text-sm font-medium">Name</label>
                <input className="mt-1 w-full rounded-xl border border-neutral-300 px-3 py-2" placeholder="Your full name" required />
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium">Phone</label>
                  <input className="mt-1 w-full rounded-xl border border-neutral-300 px-3 py-2" placeholder="(###) ###‑####" />
                </div>
                <div>
                  <label className="text-sm font-medium">Email</label>
                  <input type="email" className="mt-1 w-full rounded-xl border border-neutral-300 px-3 py-2" placeholder="you@email.com" />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">Service Needed</label>
                <select className="mt-1 w-full rounded-xl border border-neutral-300 px-3 py-2">
                  {services.map((s) => <option key={s.name}>{s.name}</option>)}
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Address (City)</label>
                <input className="mt-1 w-full rounded-xl border border-neutral-300 px-3 py-2" placeholder="Mesa / Phoenix area" />
              </div>
              <button type="button" onClick={() => alert('When your Jobber link is ready, this button will open your live booking flow.')} className="mt-2 inline-flex items-center justify-center gap-2 px-4 py-2 rounded-2xl bg-amber-500 text-white text-sm font-semibold shadow hover:shadow-md">
                <CalendarCheck2 className="w-4 h-4" /> Continue to Booking
              </button>
              <p className="text-xs text-neutral-500 mt-2">Bookings are requests—Diane will confirm availability by text or email.</p>
            </form>
          </div>
        </div>
      </section>

      <section id="contact" className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Contact</h2>
            <p className="mt-2 text-neutral-700">Have a question? Reach out any time—we're happy to help.</p>
            <div className="mt-5 space-y-2 text-neutral-800">
              <a className="flex items-center gap-2" href={`tel:${business.phone}`}><Phone className="w-5 h-5" /> {business.phone}</a>
              <a className="flex items-center gap-2" href={`mailto:${business.email}`}><Mail className="w-5 h-5" /> {business.email}</a>
              <p className="flex items-center gap-2"><MapPin className="w-5 h-5" /> {business.addressShort}</p>
            </div>
          </div>
          <div className="rounded-3xl bg-neutral-50 border border-neutral-200 p-6">
            <h3 className="font-semibold">Service Area</h3>
            <p className="text-sm text-neutral-700 mt-1">Mesa, Phoenix, Tempe, Chandler, Gilbert, Scottsdale, and nearby communities.</p>
            <div className="mt-4 rounded-2xl overflow-hidden border border-neutral-200">
              <iframe title="Mesa Area Map" src="https://www.openstreetmap.org/export/embed.html?bbox=-112.3%2C33.2%2C-111.5%2C33.6&layer=mapnik" className="w-full h-64" loading="lazy" />
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-neutral-900 text-neutral-200">
        <div className="max-w-6xl mx-auto px-4 py-10 grid md:grid-cols-2 gap-6">
          <div>
            <p className="font-semibold">{business.name}</p>
            <p className="text-sm mt-1">{business.tagline}</p>
            <p className="text-xs text-neutral-400 mt-4">Weekdays {business.hours}. Licensed & Insured.</p>
          </div>
          <div className="md:text-right space-y-2">
            <a href={business.bookingUrl} className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-amber-500 text-white text-sm font-semibold shadow hover:shadow-md">
              <CalendarCheck2 className="w-4 h-4" /> Book Now
            </a>
            <div className="text-sm"><a href={`tel:${business.phone}`}>Call {business.phone}</a> • <a href={`mailto:${business.email}`}>Email</a></div>
          </div>
        </div>
        <div className="border-t border-neutral-800">
          <div className="max-w-6xl mx-auto px-4 py-4 text-xs text-neutral-500 flex flex-wrap items-center justify-between gap-2">
            <span>© {new Date().getFullYear()} {business.name}. All rights reserved.</span>
            <span>Payments accepted: Zelle, Venmo, Cash, Check</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
