import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Heaven Sent House Cleaning — Mesa & Greater Phoenix",
  description: "Professional home and office cleaning in Mesa & Greater Phoenix. Standard, Deep, Move‑In/Out, and Airbnb Turnovers.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
